#include "rrdu_hal.h"

static uint32_t s_stat = 0;
static uint32_t s_fault = 0;

static uint32_t s_last_meas_id = 0;
static uint32_t s_last_raw = 0;
static uint32_t s_last_out = 0;

static rrdu_hal_meas_cb_t s_cb = 0;
static void* s_cb_user = 0;
static int s_meas_inflight = 0;

void rrdu_hal_init(void)
{
    s_stat = 0;
    s_fault = 0;
    s_last_meas_id = 0;
    s_last_raw = 0;
    s_last_out = 0;
    s_cb = 0;
    s_cb_user = 0;
    s_meas_inflight = 0;
}

rrdu_hal_status_t rrdu_hal_configure_defaults(void)
{
    /* Fake: accept */
    return RRDU_HAL_OK;
}

rrdu_hal_status_t rrdu_hal_read_stat(uint32_t* stat)
{
    if (!stat) return RRDU_HAL_ERR;
    *stat = s_stat;
    return RRDU_HAL_OK;
}

rrdu_hal_status_t rrdu_hal_read_fault(uint32_t* fault)
{
    if (!fault) return RRDU_HAL_ERR;
    *fault = s_fault;
    return RRDU_HAL_OK;
}

rrdu_hal_status_t rrdu_hal_fault_clear(uint32_t mask)
{
    /* W1C style */
    s_fault &= ~mask;
    return RRDU_HAL_OK;
}

rrdu_hal_status_t rrdu_hal_meas_start_async(uint32_t meas_id,
                                            rrdu_hal_meas_cb_t cb,
                                            void* user)
{
    if (s_meas_inflight) return RRDU_HAL_BUSY;

    s_meas_inflight = 1;
    s_last_meas_id = meas_id;
    s_cb = cb;
    s_cb_user = user;

    /* Fake: completion external trigger ile gelecek */
    return RRDU_HAL_OK;
}

rrdu_hal_status_t rrdu_hal_read_meas_raw(uint32_t meas_id, uint32_t* raw)
{
    if (!raw) return RRDU_HAL_ERR;
    if (!s_meas_inflight && meas_id == s_last_meas_id) {
        *raw = s_last_raw;
        return RRDU_HAL_OK;
    }
    /* Ölçüm tamamlandıktan sonra s_meas_inflight=0 oluyor,
       bu fonksiyon o durumda da çalışsın diye basit tuttuk. */
    if (meas_id != s_last_meas_id) return RRDU_HAL_ERR;

    *raw = s_last_raw;
    return RRDU_HAL_OK;
}

rrdu_hal_status_t rrdu_hal_write_output_u32(uint32_t out)
{
    s_last_out = out;
    return RRDU_HAL_OK;
}

/* Host sim: “IRQ done” gibi düşün */
void rrdu_hal_fake_complete_meas(uint32_t meas_id, uint32_t raw, uint32_t fault_mask)
{
    if (!s_meas_inflight) return;
    if (meas_id != s_last_meas_id) return;

    s_last_raw = raw;
    s_fault |= fault_mask;

    s_meas_inflight = 0;

    if (s_cb) {
        rrdu_hal_meas_cb_t cb = s_cb;
        void* user = s_cb_user;
        s_cb = 0;
        s_cb_user = 0;

        cb(user, (fault_mask != 0) ? RRDU_HAL_ERR : RRDU_HAL_OK);
    }
}
