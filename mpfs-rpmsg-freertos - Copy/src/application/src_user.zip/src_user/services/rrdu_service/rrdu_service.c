#include "rrdu_service.h"
#include "drivers/rrdu/rrdu_hal.h"
#include "core/event_queue.h"
#include "core/units.h"
#include "FreeRTOS.h"

#ifdef HOST_SIM
#include <stdio.h>
#define RRDU_LOG(...) do { printf(__VA_ARGS__); } while (0)
#else
#define RRDU_LOG(...) do { } while (0)
#endif

/* 0 = happy path, 1 = fault path (simde fault inject)  */
#ifndef RRDU_INJECT_FAULT
#define RRDU_INJECT_FAULT 1
#endif


typedef enum {
    RRDU_SVC_RESET = 0,

    RRDU_SVC_BU_CONFIG,                 /* bringup sequence for RRDU is divided into multiple status */
    RRDU_SVC_BU_HEALTH,
    RRDU_SVC_BU_MEAS_START,
    RRDU_SVC_BU_WAIT_MEAS,
    RRDU_SVC_BU_READ_AND_PUBLISH,

    RRDU_SVC_READY,
    RRDU_SVC_FAILED
} rrdu_state_t;

static rrdu_state_t s_state = RRDU_SVC_RESET;

static uint32_t s_last_raw = 0;
static uint32_t s_last_out = 0;
static uint32_t s_meas_id = 1;

static void rrdu_advance(void);

static uint32_t rrdu_scale_raw_to_u32(uint32_t raw)
{
    /* Şimdilik placeholder:
       Gerçekte TRS’ye göre scaling burada yapılacak.
       Şimdilik raw’ı direkt geçiriyoruz. */
    return raw;
}

static void rrdu_meas_cb(void* user, rrdu_hal_status_t st)
{
    (void)user;

    if (s_state != RRDU_SVC_BU_WAIT_MEAS) return;

    BaseType_t hpw = pdFALSE;
    event_t e = {0};

    if (st == RRDU_HAL_OK) {
        e.type = EVT_RRDU_MEAS_DONE;
        e.data.rrdu.st = 0;
    } else {
        e.type = EVT_RRDU_MEAS_FAILED;
        e.data.rrdu.st = (int32_t)st;
    }

    (void)eventq_push_from_isr(&e, &hpw);

    /* If the callback is ISR-context, this is correct.
       If it's task-context, this macro usually compiles but is harmless. */
    portYIELD_WITHIN_API();
}

void rrdu_service_init(void)
{
    rrdu_hal_init();
    s_state = RRDU_SVC_RESET;
    s_last_raw = 0;
    s_last_out = 0;
    s_meas_id = 1;
}

void rrdu_service_bringup_start(void)
{
        RRDU_LOG("[RRDU] bringup_start\n");

    /* idempotent: tekrar gelirse yok say */
        if (s_state != RRDU_SVC_RESET) return;

        s_state = RRDU_SVC_BU_CONFIG;
        rrdu_advance();
}


static void rrdu_advance(void)
{
    while (1) {
        if (s_state == RRDU_SVC_BU_CONFIG) {

            RRDU_LOG("[RRDU] CONFIG\n");

            if (rrdu_hal_configure_defaults() != RRDU_HAL_OK) {
                s_state = RRDU_SVC_FAILED;
                post_unit_failed(UNIT_RRDU, -100);
                return;
            }
            s_state = RRDU_SVC_BU_HEALTH;
            continue;
        }

        if (s_state == RRDU_SVC_BU_HEALTH) {

            RRDU_LOG("[RRDU] HEALTH\n");

            uint32_t stat = 0, fault = 0;



            if (rrdu_hal_read_stat(&stat) != RRDU_HAL_OK ||
                rrdu_hal_read_fault(&fault) != RRDU_HAL_OK) {
                s_state = RRDU_SVC_FAILED;
                post_unit_failed(UNIT_RRDU, -101);
                return;
            }

            /* Health gate: fault varsa fail */
            if (fault != 0) {
                RRDU_LOG("[RRDU] HEALTH fault=0x%08lx\n", (unsigned long)fault);
                s_state = RRDU_SVC_FAILED;
                post_unit_failed(UNIT_RRDU, (int32_t)fault);
                return;
            }

            RRDU_LOG("[RRDU] HEALTH ok\n");

            s_state = RRDU_SVC_BU_MEAS_START;
            continue;
        }

        if (s_state == RRDU_SVC_BU_MEAS_START) {

            RRDU_LOG("[RRDU] MEAS_START id=%lu\n", (unsigned long)s_meas_id);

            if (rrdu_hal_meas_start_async(s_meas_id, rrdu_meas_cb, 0) != RRDU_HAL_OK) {
                s_state = RRDU_SVC_FAILED;
                post_unit_failed(UNIT_RRDU, -102);
                return;
            }

            /* Burada bekleyeceğiz: completion callback ile gelecek */
            RRDU_LOG("[RRDU] WAIT_MEAS\n");
            s_state = RRDU_SVC_BU_WAIT_MEAS;
            return;
        }

        if (s_state == RRDU_SVC_BU_READ_AND_PUBLISH) {

            RRDU_LOG("[RRDU] READ_AND_PUBLISH\n");

            if (rrdu_hal_read_meas_raw(s_meas_id, &s_last_raw) != RRDU_HAL_OK) {
                s_state = RRDU_SVC_FAILED;
                post_unit_failed(UNIT_RRDU, -103);
                return;
            }

            s_last_out = rrdu_scale_raw_to_u32(s_last_raw);

            (void)rrdu_hal_write_output_u32(s_last_out);


            RRDU_LOG("[RRDU] PUBLISH raw=0x%08lx out=0x%08lx\n",
                                 (unsigned long)s_last_raw, (unsigned long)s_last_out);
            RRDU_LOG("[RRDU] READY\n");

            s_state = RRDU_SVC_READY;
            post_unit_ready(UNIT_RRDU);
            return;
        }

        return;
    }
}

/* Host sim: RRDU measurement completion tetikle */
void rrdu_service_simulate_ready(void)
{
    if (s_state != RRDU_SVC_BU_WAIT_MEAS && s_state != RRDU_SVC_BU_MEAS_START) {
        /* Sim harness yanlış sırada çağırırsa sessizce dön */
        return;
    }

    /* Fake “IRQ done”: raw=0x12345678, fault=0 */

    /* both paths (switch) */


    RRDU_LOG("[RRDU] inject_fault=%d\n", (int)RRDU_INJECT_FAULT);

    rrdu_hal_fake_complete_meas(
        s_meas_id,
        0x12345678u,
        RRDU_INJECT_FAULT ? 0x1u : 0u
    );

}

/* Nominal placeholder */
int rrdu_service_measure_start(uint32_t meas_id)
{
    (void)meas_id;
    if (s_state != RRDU_SVC_READY) return -1;
    return -2;
}

void rrdu_service_on_meas_done(void)
{
    if (s_state != RRDU_SVC_BU_WAIT_MEAS) return;
    s_state = RRDU_SVC_BU_READ_AND_PUBLISH;
    rrdu_advance();
}

void rrdu_service_on_meas_failed(int32_t st)
{
    if (s_state != RRDU_SVC_BU_WAIT_MEAS) return;
    s_state = RRDU_SVC_FAILED;
    post_unit_failed(UNIT_RRDU, st);
}
