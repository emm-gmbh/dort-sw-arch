#pragma once
#include <stdint.h>


void rrdu_service_init(void);

/* Bring-up: ready olunca post_unit_ready(UNIT_RRDU) üretilecek */
void rrdu_service_bringup_start(void);

/* Donanım yokken zinciri ilerletmek için sim */
void rrdu_service_simulate_ready(void);

/* Nominal placeholder (şimdilik boş olabilir) */
int rrdu_service_measure_start(uint32_t meas_id);


void rrdu_service_on_meas_done(void);
void rrdu_service_on_meas_failed(int32_t st);
